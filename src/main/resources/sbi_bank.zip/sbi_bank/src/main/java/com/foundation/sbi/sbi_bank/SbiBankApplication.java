package com.foundation.sbi.sbi_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbiBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbiBankApplication.class, args);
	}

}
