package com.foundation.sbi.sbi_bank.model;

public class AccountTypeDetails {
    private String type;

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}
