package com.foundation.sbi.sbi_bank.service;

import com.foundation.sbi.sbi_bank.entity.Account;
import com.foundation.sbi.sbi_bank.entity.AccountType;
import com.foundation.sbi.sbi_bank.entity.Contact;
import com.foundation.sbi.sbi_bank.entity.Customer;
import com.foundation.sbi.sbi_bank.model.AccountDetails;
import com.foundation.sbi.sbi_bank.model.ContactDetails;
import com.foundation.sbi.sbi_bank.model.CustomerDetails;
import com.foundation.sbi.sbi_bank.repository.AccountRepository;
import com.foundation.sbi.sbi_bank.repository.AccountTypeRepository;
import com.foundation.sbi.sbi_bank.repository.ContactRepository;
import com.foundation.sbi.sbi_bank.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    ContactRepository contactRepository;
    @Autowired
    private AccountTypeRepository accountTypeRepository;

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
    public String addCustomerDetails(CustomerDetails customerDetails) {

        return "";
    }

    public Customer updateCustomers(Customer customer) {

        return customerRepository.save(customer);
    }
    public void deleteAllCustomers() {
        customerRepository.deleteAll();
    }

    public Customer getCustomerByName(String customerName) {
        return customerRepository.findByFirstName(customerName);
    }

    public String deleteById(int id) {
        customerRepository.deleteById(id);
        return "Customer deleted Successfully with id: " + id;
    }

    public CustomerDetails getCustomerDetails(String customerId) {
        Optional<Customer> customerById = customerRepository.findByIdentificationNumber(customerId);
        Customer customer = customerById.get();
        Account accountByIdentificationNumber = accountRepository.findByCustomer_IdentificationNumber(customer.getIdentificationNumber());
        Optional<Contact> contactByIdentificationNumber = contactRepository.findByCustomer_IdentificationNumber(customer.getIdentificationNumber());
        Contact contact = contactByIdentificationNumber.get();
        Optional<AccountType> accountTypeById = accountTypeRepository.findById(accountByIdentificationNumber.getAccountType().getId());
        AccountType accountType = accountTypeById.get();
        return getCustomerDetails(customer, accountByIdentificationNumber, contact, accountType);
    }

    private  CustomerDetails getCustomerDetails(Customer customer, Account accountByIdentificationNumber, Contact contact, AccountType accountType) {
        CustomerDetails customerDetails = new CustomerDetails();
        customerDetails.setFirstName(customer.getFirstName());
        customerDetails.setMiddleName(customer.getMiddleName());
        customerDetails.setLastName(customer.getMiddleName());
        customerDetails.setIdentificationNumber(customer.getIdentificationNumber());

        ContactDetails contactDetails = new ContactDetails();
        contactDetails.setEmailId(contact.getEmailId());
        contactDetails.setPhone_No(contact.getPhone_No());
        contactDetails.setAddress(contact.getAddress());
        contactDetails.setCity(contact.getCity());
        contactDetails.setState(contact.getState());
        contactDetails.setCountry(contact.getCountry());
        customerDetails.setContactDetails(contactDetails);

        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setAccountType(accountType.getType());
        accountDetails.setAccountNumber(accountByIdentificationNumber.getAccountNumber());
        accountDetails.setCurrentBalance(accountByIdentificationNumber.getCurrentBalance());
        customerDetails.setAccountDetails(accountDetails);
        return customerDetails;
    }
}
