package com.foundation.sbi.sbi_bank.controller;


import com.foundation.sbi.sbi_bank.entity.Customer;
import com.foundation.sbi.sbi_bank.repository.AccountRepository;
import com.foundation.sbi.sbi_bank.model.CustomerDetails;
import com.foundation.sbi.sbi_bank.service.CustomerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BankController {
   private final CustomerService customerService;
    private final AccountRepository accountRepository;
    public BankController(CustomerService customerService,
                          AccountRepository accountRepository) {
        this.customerService = customerService;
        this.accountRepository = accountRepository;
    }
    @GetMapping("/test")
    public String name() {
        return "Akshay";
    }
    @GetMapping("/getAllCustomers")
    public List<Customer> getAllCustomers(){
        return customerService.getAllCustomers();
    }
    @GetMapping("/getCustomerByName/{customerName}")
    public Customer getCustomerByName(@PathVariable String customerName){
        return customerService.getCustomerByName(customerName);
    }
    @PostMapping("/customer-details")
    public String addCustomerDetails(@RequestBody CustomerDetails customerDetails){

        return customerService.addCustomerDetails(customerDetails);
    }
    @PutMapping("/updateCustomers")
    public Customer updateCustomers(@RequestBody Customer customer){
        return customerService.updateCustomers(customer);
    }
    @DeleteMapping("/deleteAllCustomers")
    public void deleteAllCustomers(){
        customerService.deleteAllCustomers();
    }
    @DeleteMapping("/deleteById/{id}")
    public String deleteById(@PathVariable int id){
       return customerService.deleteById(id);
    }
    @GetMapping("/customer/{idn}")
    public CustomerDetails getCustomerDetails(@PathVariable String idn) {
        return customerService.getCustomerDetails(idn);
    }

}
