INSERT INTO customer ( first_name, middle_name,last_name,identification_number)
VALUES ('Ayush', 'Kumar', 'Gupta', 'BHG76');

INSERT INTO Account_type (type)
VALUES('Joint');

INSERT INTO Account (account_number,customer_id,account_type_id,current_balance)
VALUES(939423209,(select id from customer where identification_number = 'BHG76'),(select id from account_type where type = 'Joint'),(89765));

INSERT INTO Contact (customer_id,email_id,phone_no,address,city,state,country)
VALUES ((select id from customer where identification_number = 'BHG76'),'ak@gmail.com',73683682,'TataNagar','Tata','Jharkhand','India');